import express from 'express';

export function questsRouter() {
    const router = express.Router();

    // TODO: Task 1

    // TODO: Task 2

    // TODO: Task 3

    // TODO: Task 4

    return router;
}