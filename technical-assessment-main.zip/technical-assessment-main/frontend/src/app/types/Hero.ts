export interface Hero {
    id: string,
    name: string,
    class: string,
    level: number,
}